package com.rabobank.statement.model;

public interface Status {

	public String getStatusCode();

	public void setStatusCode(String statusCode);

	public String getStatusDescription();

	public void setStatusDescription(String statusDescription);

}
