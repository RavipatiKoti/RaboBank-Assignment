package com.rabobank.statement.swaggerconfig;

public class Documentation {

	private Documentation() {

	}

	public static final String STATMENT_PROCESS_FAILED = "This endpoint will be display the Failed transaction details with transaction reference and description ";
}
