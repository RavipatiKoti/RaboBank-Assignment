package com.rabobank.statement.constants;

public interface ResponseCode {

	public String getCode();

	public String getDescrption();

}