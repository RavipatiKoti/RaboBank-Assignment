package com.rabobank.statement.model;

public interface Response {

	public Status getStatus();

}