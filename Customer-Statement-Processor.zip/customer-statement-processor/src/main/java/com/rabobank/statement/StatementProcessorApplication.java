package com.rabobank.statement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StatementProcessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(StatementProcessorApplication.class, args);
	}

}
