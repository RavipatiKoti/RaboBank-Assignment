package com.rabobank.statement.model;

import com.rabobank.statement.constants.ResponseCode;

public interface ServiceResponse {

	public ResponseCode getServiceResponse();
}