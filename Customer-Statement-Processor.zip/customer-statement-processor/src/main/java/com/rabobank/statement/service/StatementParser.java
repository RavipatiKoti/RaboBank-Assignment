package com.rabobank.statement.service;

import java.io.File;
import java.util.List;

import com.rabobank.statement.exception.StatementProcessorException;
import com.rabobank.statement.parser.service.Transaction;



/**
 * Statement parser interface which need to be implemented by file parser
 * 
 *
 */
public interface StatementParser {

	public List<Transaction> parse(File file) throws StatementProcessorException;

}
