Requirement:
Rabobank receives monthly deliveries of customer statement records. This information is delivered in two formats, 
CSV and XML. These records need to be validated. based on below conditions

1.All transaction references should be unique.
2.End balance needs to be validated.

Steps :
1.Download the project and unzip it
2.Import the project in Eclipse
3.Run as Java Application from StatementProcessorApplication.java.
4.Application Launches on Port 9001,we can able to change this port from application.properties file which is under
"src/main/resources" folder.
5.We can test this application via Postman or Swagger UI

Postman:
1.Launch the postman
Create a new request and choose Method as Post.
Choose Accept :application/json in the Header Section
Navigate to Body tab in the request,select the form-data radio button
provide key as "file"
value as "choose file from the path".
Click on "Send" Button
Then observe the response as below

Response :

I) All Records are Valid in CSV OR XML
{
    "status": {
        "status_code": "1002",
        "status_desc": "no failure record found"
    }
}


II) InValid Records in Input CSV OR XML
{
	"status": {
		"status_code": "1001",
		"status_desc": "failure records retrieved"
	},
	"failure_records": [
		{
			"reference": 165102,
			"description": "Tickets from Erik de Vries"
		},
		{
			"reference": 165102,
			"description": "Tickets for Rik Theu"
		}
	]
}

III)Invalid File Format other than "CSV" or "XML"
{
    "status": {
        "status_code": "400",
        "status_desc": "validation error"
    }
}

IV)InValid Data format like columns datatype not match with value datatype like invalidRecords.csv 
   
{
    "status": {
        "status_code": "1003",
        "status_desc": "error reteriving record"
    }
}



